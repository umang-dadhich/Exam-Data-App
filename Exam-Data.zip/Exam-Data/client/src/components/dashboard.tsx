import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { type AppData, type Topic, type DailyStatus, type Task } from "@shared/schema";
import { MOTIVATIONAL_QUOTES } from "@/lib/quotes";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Clock, Target, Quote, RotateCcw, AlertCircle, 
  CalendarDays, FileText, Plus, Trash2, CheckCircle2,
  FileUp, Eye, Lock, Zap, History, XCircle, Edit2, ListTodo, Calendar, Save
} from "lucide-react";
import { differenceInSeconds, format, parseISO } from "date-fns";
import { useToast } from "@/hooks/use-toast";

type DashboardProps = {
  data: AppData;
  onUpdateExam: (exam: AppData['exam']) => void;
  onUpdateNotes: (notes: string) => void;
  onAddTopic: (name: string) => void;
  onToggleTopic: (id: string) => void;
  onDeleteTopic: (id: string) => void;
  onUpsertTask: (task: Omit<Task, 'id' | 'createdAt' | 'completed'> & { id?: string }) => void;
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onUpdateSyllabus: (pdf: AppData['syllabusPdf']) => void;
  onLogDailyStatus: (status: DailyStatus['status']) => void;
  onReset: () => void;
};

export function Dashboard({ 
  data, onUpdateExam, onUpdateNotes, onAddTopic, onToggleTopic, 
  onDeleteTopic, onUpsertTask, onToggleTask, onDeleteTask, 
  onUpdateSyllabus, onLogDailyStatus, onReset 
}: DashboardProps) {
  const { toast } = useToast();
  const [quote, setQuote] = useState("");
  const [newTopic, setNewTopic] = useState("");
  const [notes, setNotes] = useState(data.notes);
  const [timeLeft, setTimeLeft] = useState({
    days: 0, hours: 0, minutes: 0, seconds: 0,
    isPast: false, isToday: false,
  });

  // Task Form State
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDetails, setTaskDetails] = useState("");
  const [taskDate, setTaskDate] = useState("");
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];
  const todayStatus = data.dailyHistory.find(h => h.date === todayStr);

  useEffect(() => {
    setQuote(MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)]);
  }, []);

  useEffect(() => {
    if (!data.exam) return;
    const calculateTimeLeft = () => {
      const targetDate = new Date(data.exam!.date);
      targetDate.setHours(23, 59, 59, 999);
      const now = new Date();
      const diff = differenceInSeconds(targetDate, now);

      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true, isToday: targetDate.toDateString() === now.toDateString() });
        return;
      }

      setTimeLeft({
        days: Math.floor(diff / (3600 * 24)),
        hours: Math.floor((diff % (3600 * 24)) / 3600),
        minutes: Math.floor((diff % 3600) / 60),
        seconds: Math.floor(diff % 60),
        isPast: false,
        isToday: Math.floor(diff / (3600 * 24)) === 0
      });
    };
    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [data.exam?.date]);

  const remainingTopics = data.topics.filter(t => !t.completed).length;
  const daysLeft = Math.max(1, timeLeft.days);
  const todayTargetCount = Math.ceil(remainingTopics / daysLeft);

  const totalDaysLog = data.dailyHistory.length;
  const completedDays = data.dailyHistory.filter(h => h.status === 'completed').length;
  const disciplineScore = totalDaysLog > 0 ? Math.round((completedDays / totalDaysLog) * 100) : 0;

  let currentStreak = 0;
  const sortedHistory = [...data.dailyHistory].sort((a, b) => b.date.localeCompare(a.date));
  for (let i = 0; i < sortedHistory.length; i++) {
    if (sortedHistory[i].status === 'completed') currentStreak++;
    else break;
  }

  const handleSaveTask = () => {
    if (!taskTitle || !taskDate) return;
    onUpsertTask({
      id: editingTaskId || undefined,
      title: taskTitle,
      details: taskDetails,
      date: taskDate
    });
    setTaskTitle("");
    setTaskDetails("");
    setTaskDate("");
    setEditingTaskId(null);
    toast({ title: "Task Saved", description: "Your daily plan has been updated." });
  };

  const handleSaveNotes = () => {
    onUpdateNotes(notes);
    toast({ title: "Notes Saved", description: "Your preparation notes are secure." });
  };

  const handleEditTask = (task: Task) => {
    setTaskTitle(task.title);
    setTaskDetails(task.details);
    setTaskDate(task.date);
    setEditingTaskId(task.id);
  };

  const sortedTasks = [...data.tasks].sort((a, b) => a.date.localeCompare(b.date));

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === "application/pdf") {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpdateSyllabus({ name: file.name, data: reader.result as string });
        toast({ title: "Syllabus Uploaded", description: "PDF has been saved to your device." });
      };
      reader.readAsDataURL(file);
    }
  };

  const viewPdf = () => {
    if (data.syllabusPdf) {
      const win = window.open();
      win?.document.write(`<iframe src="${data.syllabusPdf.data}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
    }
  };

  return (
    <div className="pb-24">
      <Tabs defaultValue="home" className="w-full">
        <TabsList className="grid grid-cols-4 w-full h-14 bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-100 rounded-none mb-6">
          <TabsTrigger value="home" className="data-[state=active]:text-blue-600 data-[state=active]:bg-blue-50/50 rounded-lg"><Clock className="w-4 h-4" /></TabsTrigger>
          <TabsTrigger value="planner" className="data-[state=active]:text-indigo-600 data-[state=active]:bg-indigo-50/50 rounded-lg"><ListTodo className="w-4 h-4" /></TabsTrigger>
          <TabsTrigger value="syllabus" className="data-[state=active]:text-purple-600 data-[state=active]:bg-purple-50/50 rounded-lg"><CheckCircle2 className="w-4 h-4" /></TabsTrigger>
          <TabsTrigger value="notes" className="data-[state=active]:text-slate-600 data-[state=active]:bg-slate-50/50 rounded-lg"><FileText className="w-4 h-4" /></TabsTrigger>
        </TabsList>

        {/* HOME TAB - COUNTDOWN & DISCIPLINE */}
        <TabsContent value="home" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <Card className="glass-card border-none shadow-xl overflow-hidden bg-gradient-to-br from-blue-600 to-indigo-700 text-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-2xl font-display font-black truncate max-w-[200px]">{data.exam?.name}</h3>
                  <p className="text-blue-100 text-xs font-bold uppercase tracking-widest opacity-80">Remaining Time</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => onUpdateExam(null)} className="text-white/40 hover:text-white hover:bg-white/10">
                  <Edit2 className="w-4 h-4" />
                </Button>
              </div>
              <div className="grid grid-cols-4 gap-2">
                <TimeBlock label="Days" value={timeLeft.days} inverted />
                <TimeBlock label="Hours" value={timeLeft.hours} inverted />
                <TimeBlock label="Mins" value={timeLeft.minutes} inverted />
                <TimeBlock label="Secs" value={timeLeft.seconds} inverted />
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-4">
            <Card className="border-none shadow-xl bg-white p-5 border-l-4 border-yellow-400">
              <Zap className="w-5 h-5 mb-1 text-yellow-500" />
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Streak</p>
              <div className="text-2xl font-display font-black text-slate-800">{currentStreak} Days</div>
              <p className="text-[9px] text-slate-400 mt-1 font-medium">Best: {data.bestStreak}</p>
            </Card>
            <Card className="border-none shadow-xl bg-white p-5 border-l-4 border-blue-500">
              <Target className="w-5 h-5 mb-1 text-blue-500" />
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Discipline</p>
              <div className="text-2xl font-display font-black text-slate-800">{disciplineScore}%</div>
              <Progress value={disciplineScore} className="h-1 mt-2" />
            </Card>
          </div>

          <Card className="border-none shadow-xl bg-white overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <Lock className="w-5 h-5 text-slate-400" />
                <h3 className="font-display font-bold text-slate-800">Commitment Lock</h3>
              </div>
              <div className="bg-slate-50 rounded-2xl p-6 text-center mb-6 border border-slate-100">
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Today's Target</p>
                <h4 className="text-3xl font-display font-black text-slate-800">{todayTargetCount} Topics</h4>
              </div>
              {todayStatus ? (
                <div className="flex items-center justify-center gap-3 p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <p className="text-slate-500 font-bold text-sm">Status: {todayStatus.status.toUpperCase()}</p>
                  {todayStatus.status === 'completed' ? <CheckCircle2 className="w-6 h-6 text-green-500" /> : <XCircle className="w-6 h-6 text-red-500" />}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  <Button onClick={() => onLogDailyStatus('completed')} className="h-14 bg-green-500 hover:bg-green-600 text-white rounded-2xl font-bold shadow-lg shadow-green-200">Completed</Button>
                  <Button onClick={() => onLogDailyStatus('missed')} variant="outline" className="h-14 border-red-200 text-red-500 rounded-2xl font-bold">Missed</Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="glass-card shadow-lg border-blue-50 text-center p-6 bg-white/50">
            <Quote className="w-6 h-6 text-blue-300 mx-auto mb-3" fill="currentColor" />
            <p className="text-slate-600 italic font-medium leading-relaxed">"{quote}"</p>
          </Card>
        </TabsContent>

        {/* PLANNER TAB */}
        <TabsContent value="planner" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <Card className="border-none shadow-xl bg-white overflow-hidden">
            <CardHeader className="bg-indigo-50/50 pb-4">
              <CardTitle className="text-lg flex items-center gap-2 text-indigo-700">
                <ListTodo className="w-5 h-5" /> Daily Planner
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <Input placeholder="What's the goal today?" value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} className="bg-slate-50 border-none h-12 rounded-xl text-lg font-medium" />
              <Textarea placeholder="Details (Optional)..." value={taskDetails} onChange={(e) => setTaskDetails(e.target.value)} className="bg-slate-50 border-none rounded-xl min-h-[80px]" />
              <div className="grid grid-cols-2 gap-3">
                <Input type="date" value={taskDate} onChange={(e) => setTaskDate(e.target.value)} className="bg-slate-50 border-none h-12 rounded-xl" />
                <Button onClick={handleSaveTask} className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl h-12 font-bold">
                  {editingTaskId ? "Update" : "Add Task"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            {sortedTasks.map(task => (
              <Card key={task.id} className={`border-none shadow-md overflow-hidden transition-all ${task.completed ? 'bg-green-50/30 opacity-80' : 'bg-white'}`}>
                <CardContent className="p-4 flex gap-4 items-start">
                  <Checkbox checked={task.completed} onCheckedChange={() => onToggleTask(task.id)} className="mt-1 w-6 h-6 rounded-lg data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500" />
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <h4 className={`font-bold ${task.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{task.title}</h4>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" onClick={() => handleEditTask(task)} className="h-7 w-7 text-blue-400"><Edit2 className="w-3.5 h-3.5" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => onDeleteTask(task.id)} className="h-7 w-7 text-red-400"><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
                      <Calendar className="w-3 h-3" /> {format(parseISO(task.date), 'MMM dd')}
                    </div>
                    {task.details && <p className="text-xs text-slate-500 mt-2 line-clamp-2">{task.details}</p>}
                  </div>
                </CardContent>
              </Card>
            ))}
            {sortedTasks.length === 0 && <p className="text-center text-slate-400 py-20 text-sm">Your schedule is empty.</p>}
          </div>
        </TabsContent>

        {/* SYLLABUS TAB */}
        <TabsContent value="syllabus" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <Card className="border-none shadow-xl bg-white overflow-hidden">
            <CardHeader className="bg-purple-50/50 pb-4">
              <CardTitle className="text-lg flex items-center justify-between text-purple-700">
                <span className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5" /> Syllabus Progress</span>
                <span className="text-xl font-display font-black">{Math.round((data.topics.filter(t => t.completed).length / (data.topics.length || 1)) * 100)}%</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="flex gap-2">
                <Input placeholder="Enter topic name..." value={newTopic} onChange={(e) => setNewTopic(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (onAddTopic(newTopic), setNewTopic(""))} className="bg-slate-50 border-none h-12 rounded-xl" />
                <Button onClick={() => { onAddTopic(newTopic); setNewTopic(""); }} className="bg-purple-600 hover:bg-purple-700 h-12 w-12 rounded-xl"><Plus className="w-5 h-5" /></Button>
              </div>

              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                {data.topics.map(topic => (
                  <div key={topic.id} className="flex items-center gap-3 p-3 bg-slate-50/80 rounded-xl group transition-all hover:bg-slate-100">
                    <Checkbox checked={topic.completed} onCheckedChange={() => onToggleTopic(topic.id)} className="rounded-lg border-slate-300 data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500" />
                    <span className={`flex-1 text-sm font-bold ${topic.completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>{topic.name}</span>
                    <Button variant="ghost" size="icon" onClick={() => onDeleteTopic(topic.id)} className="opacity-0 group-hover:opacity-100 h-8 w-8 text-red-400 transition-opacity"><Trash2 className="w-4 h-4" /></Button>
                  </div>
                ))}
                {data.topics.length === 0 && <p className="text-center text-slate-400 py-10 text-sm">No topics added yet.</p>}
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card border-none shadow-xl p-4 flex items-center justify-between bg-white">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-50 text-purple-600 rounded-lg"><FileText className="w-5 h-5" /></div>
              <span className="text-xs font-bold truncate max-w-[150px] text-slate-600">{data.syllabusPdf?.name || "No Syllabus Uploaded"}</span>
            </div>
            <div className="flex gap-1">
              {data.syllabusPdf && <Button variant="ghost" size="sm" onClick={viewPdf} className="text-purple-600 font-black text-xs uppercase">View</Button>}
              <label className="cursor-pointer text-purple-600 font-black text-xs uppercase px-2 py-1 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                {data.syllabusPdf ? "Update" : "Upload"}
                <Input type="file" accept="application/pdf" className="hidden" onChange={handleFileUpload} />
              </label>
            </div>
          </Card>
        </TabsContent>

        {/* NOTES TAB */}
        <TabsContent value="notes" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <Card className="border-none shadow-xl bg-white min-h-[500px] flex flex-col overflow-hidden">
            <CardHeader className="bg-slate-50/50 flex flex-row items-center justify-between pb-4">
              <CardTitle className="text-lg flex items-center gap-2 text-slate-700">
                <FileText className="w-5 h-5" /> Prep Notes
              </CardTitle>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" onClick={() => setNotes("")} className="h-9 w-9 text-red-400 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>
                <Button onClick={handleSaveNotes} className="bg-slate-800 hover:bg-slate-900 text-white font-bold h-9 px-4 rounded-xl flex gap-2">
                  <Save className="w-4 h-4" /> Save
                </Button>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-6">
              <Textarea 
                placeholder="Write your study plan, weak subjects, or key formulas here..."
                className="w-full h-full min-h-[400px] bg-transparent border-none p-0 focus-visible:ring-0 text-slate-700 leading-relaxed resize-none"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-center mt-8">
        <Button variant="ghost" onClick={onReset} className="text-slate-300 hover:text-red-400 text-[10px] font-bold uppercase tracking-widest gap-2">
          <RotateCcw className="w-3 h-3" /> Reset All (Danger)
        </Button>
      </div>
    </div>
  );
}

function TimeBlock({ label, value, inverted = false }: { label: string; value: number; inverted?: boolean }) {
  return (
    <div className={`flex flex-col items-center justify-center rounded-2xl p-3 border ${inverted ? 'bg-white/10 border-white/10' : 'bg-white/60 border-white shadow-sm'}`}>
      <span className={`text-2xl font-display font-black ${inverted ? 'text-white' : 'text-blue-600'}`}>{value.toString().padStart(2, '0')}</span>
      <span className={`text-[8px] font-black uppercase tracking-tighter ${inverted ? 'text-blue-100' : 'text-slate-400'}`}>{label}</span>
    </div>
  );
}

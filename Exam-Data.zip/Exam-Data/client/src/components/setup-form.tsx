import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { examDataSchema, type ExamData } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Calendar, Target, BookOpen } from "lucide-react";

// Extend the shared schema to coerce numbers since HTML inputs return strings
const formSchema = examDataSchema.extend({
  date: z.string().min(1, "Please select an exam date"),
  units: z.coerce.number().min(1, "Syllabus units must be at least 1")
});

type SetupFormProps = {
  onSave: (data: ExamData) => void;
};

export function SetupForm({ onSave }: SetupFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      date: "",
      units: 1,
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onSave(values);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <Card className="glass-card overflow-hidden border-none shadow-xl">
        <div className="h-2 w-full bg-gradient-to-r from-blue-500 to-indigo-500" />
        <CardHeader className="pb-4 text-center">
          <CardTitle className="text-2xl font-display font-bold text-slate-800">Set Your Target</CardTitle>
          <CardDescription className="text-slate-500">
            Tell us about your upcoming exam to generate your personalized study plan.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-slate-700 font-semibold flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-blue-500" /> Exam Name
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g. Final Mathematics Exam" 
                        className="bg-white/50 border-slate-200 focus:border-blue-500 focus:ring-blue-500/20 h-12 rounded-xl transition-all"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-slate-700 font-semibold flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-blue-500" /> Exam Date
                    </FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        className="bg-white/50 border-slate-200 focus:border-blue-500 focus:ring-blue-500/20 h-12 rounded-xl transition-all"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="units"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-slate-700 font-semibold flex items-center gap-2">
                      <Target className="w-4 h-4 text-blue-500" /> Total Syllabus Units
                    </FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="1"
                        placeholder="e.g. 15 chapters" 
                        className="bg-white/50 border-slate-200 focus:border-blue-500 focus:ring-blue-500/20 h-12 rounded-xl transition-all"
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription className="text-xs text-slate-500">
                      Chapters, modules, or topics you need to cover.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full h-14 text-lg font-semibold rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg shadow-blue-500/30 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 transform active:scale-95 touch-manipulation"
              >
                Start Tracking
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Inline fallback for missing FormDescription in standard shadcn
function FormDescription({ className, children }: { className?: string; children: React.ReactNode }) {
  return <p className={`mt-1 ${className}`}>{children}</p>;
}

import { motion, AnimatePresence } from "framer-motion";
import { useExamData } from "@/hooks/use-exam-data";
import { SetupForm } from "@/components/setup-form";
import { Dashboard } from "@/components/dashboard";
import { GraduationCap } from "lucide-react";
import { Toaster } from "@/components/ui/toaster";

export default function Home() {
  const { 
    data, isLoaded, updateExam, updateNotes, 
    addTopic, toggleTopic, deleteTopic, 
    upsertTask, toggleTask, deleteTask,
    updateSyllabus, logDailyStatus, resetAll 
  } = useExamData();

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC]">
        <GraduationCap className="w-12 h-12 text-blue-500 animate-pulse" />
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-[#F8FAFC] font-sans text-slate-900 overflow-x-hidden">
      {/* Dynamic Background Elements */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-100/30 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-indigo-100/30 rounded-full blur-[100px]" />
      </div>

      <div className="max-w-md w-full mx-auto px-4 pt-8 pb-6">
        <AnimatePresence mode="wait">
          {!data.exam ? (
            <div key="landing" className="min-h-[80vh] flex flex-col justify-center py-10">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-10"
              >
                <div className="inline-flex items-center justify-center p-4 bg-white shadow-2xl rounded-3xl mb-6 border border-slate-100">
                  <GraduationCap className="w-10 h-10 text-blue-600" />
                </div>
                <h1 className="text-5xl font-display font-black text-slate-900 tracking-tight mb-2">ExamDay</h1>
                <p className="text-slate-500 font-bold tracking-[0.2em] text-xs uppercase">Your Success, Systematized</p>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
              >
                <SetupForm onSave={updateExam} />
              </motion.div>
            </div>
          ) : (
            <div key="app-view">
              <header className="flex items-center justify-between mb-8 px-2">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white shadow-lg rounded-xl border border-slate-50">
                    <GraduationCap className="w-5 h-5 text-blue-600" />
                  </div>
                  <h1 className="text-2xl font-display font-black text-slate-900 tracking-tight">ExamDay</h1>
                </div>
                <div className="bg-blue-50 px-3 py-1 rounded-full">
                  <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">v2.0 Beta</span>
                </div>
              </header>

              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Dashboard 
                  data={data} 
                  onUpdateExam={updateExam}
                  onUpdateNotes={updateNotes}
                  onAddTopic={addTopic}
                  onToggleTopic={toggleTopic}
                  onDeleteTopic={deleteTopic}
                  onUpsertTask={upsertTask}
                  onToggleTask={toggleTask}
                  onDeleteTask={deleteTask}
                  onUpdateSyllabus={updateSyllabus}
                  onLogDailyStatus={logDailyStatus}
                  onReset={resetAll} 
                />
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
      <Toaster />
    </main>
  );
}

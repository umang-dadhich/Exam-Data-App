import { useState, useEffect } from 'react';
import { type AppData, type ExamData, type Topic, type DailyStatus, type Task } from '@shared/schema';

const STORAGE_KEY = 'examDayData_v4';

const DEFAULT_DATA: AppData = {
  exam: null,
  notes: "",
  topics: [],
  tasks: [],
  syllabusPdf: null,
  dailyHistory: [],
  bestStreak: 0
};

export function useExamData() {
  const [data, setData] = useState<AppData>(DEFAULT_DATA);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setData(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Failed to parse ExamDay data', e);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  const saveData = (newData: AppData) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    setData(newData);
  };

  const updateExam = (exam: ExamData | null) => saveData({ ...data, exam });
  const updateNotes = (notes: string) => saveData({ ...data, notes });
  
  const addTopic = (name: string) => {
    const newTopic: Topic = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      completed: false
    };
    saveData({ ...data, topics: [...data.topics, newTopic] });
  };

  const toggleTopic = (id: string) => {
    const newTopics = data.topics.map(t => 
      t.id === id ? { ...t, completed: !t.completed } : t
    );
    saveData({ ...data, topics: newTopics });
  };

  const deleteTopic = (id: string) => {
    saveData({ ...data, topics: data.topics.filter(t => t.id !== id) });
  };

  const upsertTask = (task: Omit<Task, 'id' | 'createdAt' | 'completed'> & { id?: string }) => {
    if (task.id) {
      const newTasks = data.tasks.map(t => 
        t.id === task.id ? { ...t, ...task } : t
      );
      saveData({ ...data, tasks: newTasks });
    } else {
      const newTask: Task = {
        ...task,
        id: Math.random().toString(36).substr(2, 9),
        completed: false,
        createdAt: Date.now()
      };
      saveData({ ...data, tasks: [...data.tasks, newTask] });
    }
  };

  const toggleTask = (id: string) => {
    const newTasks = data.tasks.map(t => 
      t.id === id ? { ...t, completed: !t.completed } : t
    );
    saveData({ ...data, tasks: newTasks });
  };

  const deleteTask = (id: string) => {
    saveData({ ...data, tasks: data.tasks.filter(t => t.id !== id) });
  };

  const updateSyllabus = (pdf: AppData['syllabusPdf']) => saveData({ ...data, syllabusPdf: pdf });

  const logDailyStatus = (status: DailyStatus['status']) => {
    const today = new Date().toISOString().split('T')[0];
    const newHistory = [...data.dailyHistory, { date: today, status }];
    
    let currentStreak = 0;
    const sortedHistory = [...newHistory].sort((a, b) => b.date.localeCompare(a.date));
    
    for (let i = 0; i < sortedHistory.length; i++) {
      if (sortedHistory[i].status === 'completed') {
        currentStreak++;
      } else {
        break;
      }
    }

    const bestStreak = Math.max(data.bestStreak, currentStreak);
    saveData({ ...data, dailyHistory: newHistory, bestStreak });
  };

  const resetAll = () => {
    localStorage.removeItem(STORAGE_KEY);
    setData(DEFAULT_DATA);
  };

  return {
    data,
    isLoaded,
    updateExam,
    updateNotes,
    addTopic,
    toggleTopic,
    deleteTopic,
    upsertTask,
    toggleTask,
    deleteTask,
    updateSyllabus,
    logDailyStatus,
    resetAll
  };
}

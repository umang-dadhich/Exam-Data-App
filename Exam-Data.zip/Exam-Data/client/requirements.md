## Packages
framer-motion | Page transitions and layout animations for a premium feel
date-fns | Reliable date manipulation and formatting

## Notes
No backend API needed. All data is saved in localStorage per instructions.
Application is fully offline and mobile-first.

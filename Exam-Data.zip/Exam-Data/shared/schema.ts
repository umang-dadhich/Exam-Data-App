import { z } from "zod";

export const examDataSchema = z.object({
  name: z.string().min(1, "Exam name is required"),
  date: z.string(), // ISO date string
  units: z.number().min(1, "Syllabus units must be at least 1")
});

export const topicSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Topic name is required"),
  completed: z.boolean().default(false)
});

export const dailyStatusSchema = z.object({
  date: z.string(), // YYYY-MM-DD
  status: z.enum(["completed", "missed"])
});

export const taskSchema = z.object({
  id: z.string(),
  title: z.string().min(1, "Task title is required"),
  details: z.string().default(""),
  date: z.string(), // YYYY-MM-DD
  completed: z.boolean().default(false),
  createdAt: z.number()
});

export const appDataSchema = z.object({
  exam: examDataSchema.nullable(),
  notes: z.string().default(""),
  topics: z.array(topicSchema).default([]),
  tasks: z.array(taskSchema).default([]),
  syllabusPdf: z.object({
    name: z.string(),
    data: z.string() // Base64
  }).nullable(),
  dailyHistory: z.array(dailyStatusSchema).default([]),
  bestStreak: z.number().default(0)
});

export type ExamData = z.infer<typeof examDataSchema>;
export type Topic = z.infer<typeof topicSchema>;
export type DailyStatus = z.infer<typeof dailyStatusSchema>;
export type Task = z.infer<typeof taskSchema>;
export type AppData = z.infer<typeof appDataSchema>;
